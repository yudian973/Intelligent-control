keyscan.h           EQU        keyscan.h

KeystokePort        EQU        0b00100000

;======================= key scan port define =========================
X_KeyLine           EQU        PORT7
X_LINE1             EQU        X_KeyLine*16+4		;R74
X_LINE2             EQU        X_KeyLine*16+5		;R73
X_LINE3             EQU        X_KeyLine*16+6		;R72
X_LINE4             EQU        X_KeyLine*16+7		;R71

X_Keyrow            EQU        PORT9
X_ROW1              EQU        X_Keyrow*16+7		;R97
X_ROW2              EQU        X_Keyrow*16+6		;R96
X_ROW3              EQU        X_Keyrow*16+5		;R95
X_ROW4              EQU        X_Keyrow*16+4		;R94

;------------------------ Define form SCH ---------------------------- 
UP                  EQU        5    ;Port85
RIGHT               EQU        4    ;Port84
DOWN                EQU        2    ;Port82
LEFT                EQU        1    ;Port81

A_1                 EQU        7    ;Port97
B_2                 EQU        6    ;Port96
C_3                 EQU        5    ;Port95
D_4                 EQU        4    ;Port94

L1_5                EQU        7    ;Port97
R1_6                EQU        6    ;Port96
L2_7                EQU        5    ;Port95
R2_8                EQU        4    ;Port94

SELECT_9            EQU        7    ;Port97
START_10            EQU        6    ;Port96
LSW_11              EQU        7    ;Port97
RSW_12              EQU        4    ;Port94

MODE_13             EQU        5    ;Port95
MACRO_14            EQU        4    ;Port94
TEST1_15            EQU        6    ;Port96
TEST2_16            EQU        5    ;Port95

;---------------------------------------------------------

_A                  EQU        0    ;DataE
_B                  EQU        1
_C                  EQU        2
_D                  EQU        3
_L1                 EQU        4
_R1                 EQU        5
_L2                 EQU        6
_R2                 EQU        7

SELECT              EQU        0    ;DataF
START               EQU        1
LSW                 EQU        2
RSW                 EQU        3
MODE                EQU        4
MACROO              EQU        5
TEST1               EQU        6
TEST2               EQU        7
