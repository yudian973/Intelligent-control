Updated: January 11, 2002
To execute the Matlab version simply execute gui.m
Enjoy.
Greg Welch